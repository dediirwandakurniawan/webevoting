webpackHotUpdate_N_E("pages/admin/event/event-detail/[eventId]",{

/***/ "./components/Event/dashboard.js":
/*!***************************************!*\
  !*** ./components/Event/dashboard.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-chartjs-2 */ "./node_modules/react-chartjs-2/es/index.js");
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_chartjs_2__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var layouts_Admin_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! layouts/Admin.js */ "./layouts/Admin.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! highcharts */ "./node_modules/highcharts/highcharts.js");
/* harmony import */ var highcharts__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(highcharts__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var highcharts_react_official__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! highcharts-react-official */ "./node_modules/highcharts-react-official/dist/highcharts-react.min.js");
/* harmony import */ var highcharts_react_official__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(highcharts_react_official__WEBPACK_IMPORTED_MODULE_11__);






var _jsxFileName = "D:\\Project\\eVoting_FE\\components\\Event\\dashboard.js",
    _this = undefined,
    _s = $RefreshSig$();

 // node.js library that concatenates classes (strings)

 // reactstrap components

 // layout for this page





 // core components

var Dashboard = function Dashboard(props) {
  _s();

  var _dataVote$series, _options;

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_8__["useRouter"])(); // const Chart = require("chart.js");

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])([]),
      dataVote = _useState[0],
      setDataVote = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false),
      showChart = _useState2[0],
      setShowChart = _useState2[1];

  var eventId = router.query.eventId;

  var getData = /*#__PURE__*/function () {
    var _ref = Object(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__["default"])( /*#__PURE__*/D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.mark(function _callee() {
      var _yield$axios$get, res;

      return D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return axios__WEBPACK_IMPORTED_MODULE_9__["default"].get("".concat("http://206.189.46.230:3030", "/dashboard/vote-candidate/").concat(eventId));

            case 2:
              _yield$axios$get = _context.sent;
              res = _yield$axios$get.data;
              setDataVote(res.data);

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function getData() {
      return _ref.apply(this, arguments);
    };
  }(); // const options = {
  //   chart: {
  //     type: "column",
  //   },
  //   title: {
  //     text: "",
  //     align: "left",
  //   },
  //   subtitle: {
  //     text: "",
  //     align: "left",
  //   },
  //   xAxis: {
  //     categories: dataVote && dataVote.categories,
  //     crosshair: true,
  //     accessibility: {
  //       description: "Kandidat",
  //     },
  //   },
  //   credits: {
  //     enabled: false,
  //   },
  //   yAxis: {
  //     min: 0,
  //     title: {
  //       text: "Jumlah",
  //     },
  //     Animation: true,
  //   },
  //   tooltip: {
  //     valueSuffix: "",
  //   },
  //   plotOptions: {
  //     column: {
  //       pointPadding: 0.2,
  //       borderWidth: 0,
  //     },
  //   },
  //   series: [{ name: "Kandidat", data: dataVote && dataVote?.series?.data }],
  // };


  var options = (_options = {
    chart: {
      type: "bar"
    },
    exporting: {
      enabled: true
    },
    title: {
      text: "",
      align: "left"
    },
    subtitle: {
      text: "",
      align: "left"
    },
    xAxis: {
      categories: dataVote && dataVote.categories,
      title: {
        text: null
      },
      gridLineWidth: 1,
      lineWidth: 0
    },
    yAxis: {
      min: 0,
      title: {
        text: "",
        align: "high"
      },
      labels: {
        overflow: "justify"
      },
      gridLineWidth: 0,
      tickInterval: 1
    },
    tooltip: {
      x: {
        formatter: function formatter(value, _ref2) {
          var series = _ref2.series,
              seriesIndex = _ref2.seriesIndex,
              dataPointIndex = _ref2.dataPointIndex,
              w = _ref2.w;
          return value;
        }
      }
    }
  }, Object(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_options, "exporting", {
    buttons: {
      contextButton: {
        menuItems: ["viewFullscreen", "separator", "downloadPNG", "downloadSVG", "downloadPDF", "separator", "downloadXLS"]
      }
    },
    enabled: true
  }), Object(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_options, "navigation", {
    buttonOptions: {
      align: "right",
      verticalAlign: "top",
      y: 0
    }
  }), Object(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_options, "plotOptions", {
    bar: {
      borderRadius: "50%",
      dataLabels: {
        enabled: true
      },
      groupPadding: 0.1
    }
  }), Object(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_options, "legend", {
    // layout: "top",
    itemDistance: 1,
    align: "center",
    verticalAlign: "bottom",
    floating: false,
    borderWidth: 1,
    backgroundColor: "#FFFFFF",
    shadow: true
  }), Object(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_options, "credits", {
    enabled: false
  }), Object(D_Project_eVoting_FE_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_options, "series", [{
    name: "Vote",
    data: dataVote && (dataVote === null || dataVote === void 0 ? void 0 : (_dataVote$series = dataVote.series) === null || _dataVote$series === void 0 ? void 0 : _dataVote$series.data)
  }]), _options);

  var handleActiveChart = function handleActiveChart() {
    getData();
    setShowChart(true);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Container"], {
      fluid: true,
      className: "mt-3",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Row"], {
        className: "justify-content-center",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Col"], {
          xl: "8",
          md: "12",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Card"], {
            className: "shadow",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["CardHeader"], {
              className: "bg-transparent",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Row"], {
                className: "align-items-center",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "col",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
                    className: "mb-0",
                    children: "Hasil Vote"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 197,
                    columnNumber: 21
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 195,
                  columnNumber: 19
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 194,
                columnNumber: 17
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 193,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["CardBody"], {
              children: [showChart === false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Button"], {
                onClick: function onClick() {
                  return handleActiveChart();
                },
                color: "success",
                className: "mb-3",
                children: "Kalkulasi Sekarang"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 203,
                columnNumber: 19
              }, _this) : null, showChart ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(highcharts_react_official__WEBPACK_IMPORTED_MODULE_11___default.a, {
                highcharts: highcharts__WEBPACK_IMPORTED_MODULE_10___default.a,
                options: options
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 217,
                columnNumber: 19
              }, _this) : null]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 201,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 192,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 191,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 190,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 189,
      columnNumber: 7
    }, _this)
  }, void 0, false);
};

_s(Dashboard, "oHr5RnfNZgad8VWYdOLCX8ovhgk=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_8__["useRouter"]];
});

_c = Dashboard;
Dashboard.layout = layouts_Admin_js__WEBPACK_IMPORTED_MODULE_7__["default"];
/* harmony default export */ __webpack_exports__["default"] = (Dashboard);

var _c;

$RefreshReg$(_c, "Dashboard");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9FdmVudC9kYXNoYm9hcmQuanMiXSwibmFtZXMiOlsiRGFzaGJvYXJkIiwicHJvcHMiLCJyb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJ1c2VTdGF0ZSIsImRhdGFWb3RlIiwic2V0RGF0YVZvdGUiLCJzaG93Q2hhcnQiLCJzZXRTaG93Q2hhcnQiLCJldmVudElkIiwicXVlcnkiLCJnZXREYXRhIiwiYXhpb3MiLCJnZXQiLCJwcm9jZXNzIiwicmVzIiwiZGF0YSIsIm9wdGlvbnMiLCJjaGFydCIsInR5cGUiLCJleHBvcnRpbmciLCJlbmFibGVkIiwidGl0bGUiLCJ0ZXh0IiwiYWxpZ24iLCJzdWJ0aXRsZSIsInhBeGlzIiwiY2F0ZWdvcmllcyIsImdyaWRMaW5lV2lkdGgiLCJsaW5lV2lkdGgiLCJ5QXhpcyIsIm1pbiIsImxhYmVscyIsIm92ZXJmbG93IiwidGlja0ludGVydmFsIiwidG9vbHRpcCIsIngiLCJmb3JtYXR0ZXIiLCJ2YWx1ZSIsInNlcmllcyIsInNlcmllc0luZGV4IiwiZGF0YVBvaW50SW5kZXgiLCJ3IiwiYnV0dG9ucyIsImNvbnRleHRCdXR0b24iLCJtZW51SXRlbXMiLCJidXR0b25PcHRpb25zIiwidmVydGljYWxBbGlnbiIsInkiLCJiYXIiLCJib3JkZXJSYWRpdXMiLCJkYXRhTGFiZWxzIiwiZ3JvdXBQYWRkaW5nIiwiaXRlbURpc3RhbmNlIiwiZmxvYXRpbmciLCJib3JkZXJXaWR0aCIsImJhY2tncm91bmRDb2xvciIsInNoYWRvdyIsIm5hbWUiLCJoYW5kbGVBY3RpdmVDaGFydCIsIkhpZ2hjaGFydHMiLCJsYXlvdXQiLCJBZG1pbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQUNBOztDQUdBOztDQWVBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0NBR0E7O0FBRUEsSUFBTUEsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsS0FBRCxFQUFXO0FBQUE7O0FBQUE7O0FBQzNCLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEIsQ0FEMkIsQ0FHM0I7O0FBSDJCLGtCQUlLQyxzREFBUSxDQUFDLEVBQUQsQ0FKYjtBQUFBLE1BSXBCQyxRQUpvQjtBQUFBLE1BSVZDLFdBSlU7O0FBQUEsbUJBS09GLHNEQUFRLENBQUMsS0FBRCxDQUxmO0FBQUEsTUFLcEJHLFNBTG9CO0FBQUEsTUFLVEMsWUFMUzs7QUFNM0IsTUFBTUMsT0FBTyxHQUFHUCxNQUFNLENBQUNRLEtBQVAsQ0FBYUQsT0FBN0I7O0FBRUEsTUFBTUUsT0FBTztBQUFBLHNTQUFHO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNjQyw2Q0FBSyxDQUFDQyxHQUFOLFdBQ3ZCQyw0QkFEdUIsdUNBQ2lDTCxPQURqQyxFQURkOztBQUFBO0FBQUE7QUFDQU0saUJBREEsb0JBQ05DLElBRE07QUFJZFYseUJBQVcsQ0FBQ1MsR0FBRyxDQUFDQyxJQUFMLENBQVg7O0FBSmM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBUEwsT0FBTztBQUFBO0FBQUE7QUFBQSxLQUFiLENBUjJCLENBZTNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxNQUFNTSxPQUFPO0FBQ1hDLFNBQUssRUFBRTtBQUNMQyxVQUFJLEVBQUU7QUFERCxLQURJO0FBS1hDLGFBQVMsRUFBRTtBQUNUQyxhQUFPLEVBQUU7QUFEQSxLQUxBO0FBUVhDLFNBQUssRUFBRTtBQUNMQyxVQUFJLEVBQUUsRUFERDtBQUVMQyxXQUFLLEVBQUU7QUFGRixLQVJJO0FBWVhDLFlBQVEsRUFBRTtBQUNSRixVQUFJLEVBQUUsRUFERTtBQUdSQyxXQUFLLEVBQUU7QUFIQyxLQVpDO0FBaUJYRSxTQUFLLEVBQUU7QUFDTEMsZ0JBQVUsRUFBRXRCLFFBQVEsSUFBSUEsUUFBUSxDQUFDc0IsVUFENUI7QUFFTEwsV0FBSyxFQUFFO0FBQ0xDLFlBQUksRUFBRTtBQURELE9BRkY7QUFLTEssbUJBQWEsRUFBRSxDQUxWO0FBTUxDLGVBQVMsRUFBRTtBQU5OLEtBakJJO0FBeUJYQyxTQUFLLEVBQUU7QUFDTEMsU0FBRyxFQUFFLENBREE7QUFFTFQsV0FBSyxFQUFFO0FBQ0xDLFlBQUksRUFBRSxFQUREO0FBRUxDLGFBQUssRUFBRTtBQUZGLE9BRkY7QUFNTFEsWUFBTSxFQUFFO0FBQ05DLGdCQUFRLEVBQUU7QUFESixPQU5IO0FBU0xMLG1CQUFhLEVBQUUsQ0FUVjtBQVVMTSxrQkFBWSxFQUFFO0FBVlQsS0F6Qkk7QUFxQ1hDLFdBQU8sRUFBRTtBQUNQQyxPQUFDLEVBQUU7QUFDREMsaUJBQVMsRUFBRSxtQkFDVEMsS0FEUyxTQUdUO0FBQUEsY0FERUMsTUFDRixTQURFQSxNQUNGO0FBQUEsY0FEVUMsV0FDVixTQURVQSxXQUNWO0FBQUEsY0FEdUJDLGNBQ3ZCLFNBRHVCQSxjQUN2QjtBQUFBLGNBRHVDQyxDQUN2QyxTQUR1Q0EsQ0FDdkM7QUFDQSxpQkFBT0osS0FBUDtBQUNEO0FBTkE7QUFESTtBQXJDRSx5S0ErQ0E7QUFDVEssV0FBTyxFQUFFO0FBQ1BDLG1CQUFhLEVBQUU7QUFDYkMsaUJBQVMsRUFBRSxDQUNULGdCQURTLEVBRVQsV0FGUyxFQUdULGFBSFMsRUFJVCxhQUpTLEVBS1QsYUFMUyxFQU1ULFdBTlMsRUFPVCxhQVBTO0FBREU7QUFEUixLQURBO0FBY1R4QixXQUFPLEVBQUU7QUFkQSxHQS9DQSx3S0ErREM7QUFDVnlCLGlCQUFhLEVBQUU7QUFDYnRCLFdBQUssRUFBRSxPQURNO0FBRWJ1QixtQkFBYSxFQUFFLEtBRkY7QUFHYkMsT0FBQyxFQUFFO0FBSFU7QUFETCxHQS9ERCx5S0FzRUU7QUFDWEMsT0FBRyxFQUFFO0FBQ0hDLGtCQUFZLEVBQUUsS0FEWDtBQUVIQyxnQkFBVSxFQUFFO0FBQ1Y5QixlQUFPLEVBQUU7QUFEQyxPQUZUO0FBS0grQixrQkFBWSxFQUFFO0FBTFg7QUFETSxHQXRFRixvS0ErRUg7QUFDTjtBQUNBQyxnQkFBWSxFQUFFLENBRlI7QUFHTjdCLFNBQUssRUFBRSxRQUhEO0FBSU51QixpQkFBYSxFQUFFLFFBSlQ7QUFLTk8sWUFBUSxFQUFFLEtBTEo7QUFNTkMsZUFBVyxFQUFFLENBTlA7QUFPTkMsbUJBQWUsRUFBRSxTQVBYO0FBUU5DLFVBQU0sRUFBRTtBQVJGLEdBL0VHLHFLQXlGRjtBQUNQcEMsV0FBTyxFQUFFO0FBREYsR0F6RkUsb0tBNEZILENBQUM7QUFBRXFDLFFBQUksRUFBRSxNQUFSO0FBQWdCMUMsUUFBSSxFQUFFWCxRQUFRLEtBQUlBLFFBQUosYUFBSUEsUUFBSiwyQ0FBSUEsUUFBUSxDQUFFa0MsTUFBZCxxREFBSSxpQkFBa0J2QixJQUF0QjtBQUE5QixHQUFELENBNUZHLFlBQWI7O0FBK0ZBLE1BQU0yQyxpQkFBaUIsR0FBRyxTQUFwQkEsaUJBQW9CLEdBQU07QUFDOUJoRCxXQUFPO0FBQ1BILGdCQUFZLENBQUMsSUFBRCxDQUFaO0FBQ0QsR0FIRDs7QUFLQSxzQkFDRTtBQUFBLDJCQUVFLHFFQUFDLG9EQUFEO0FBQVcsV0FBSyxNQUFoQjtBQUFpQixlQUFTLEVBQUMsTUFBM0I7QUFBQSw2QkFDRSxxRUFBQyw4Q0FBRDtBQUFLLGlCQUFTLEVBQUMsd0JBQWY7QUFBQSwrQkFDRSxxRUFBQyw4Q0FBRDtBQUFLLFlBQUUsRUFBQyxHQUFSO0FBQVksWUFBRSxFQUFDLElBQWY7QUFBQSxpQ0FDRSxxRUFBQywrQ0FBRDtBQUFNLHFCQUFTLEVBQUMsUUFBaEI7QUFBQSxvQ0FDRSxxRUFBQyxxREFBRDtBQUFZLHVCQUFTLEVBQUMsZ0JBQXRCO0FBQUEscUNBQ0UscUVBQUMsOENBQUQ7QUFBSyx5QkFBUyxFQUFDLG9CQUFmO0FBQUEsdUNBQ0U7QUFBSywyQkFBUyxFQUFDLEtBQWY7QUFBQSx5Q0FFRTtBQUFJLDZCQUFTLEVBQUMsTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVNFLHFFQUFDLG1EQUFEO0FBQUEseUJBQ0dELFNBQVMsS0FBSyxLQUFkLGdCQUNDLHFFQUFDLGlEQUFEO0FBQ0UsdUJBQU8sRUFBRTtBQUFBLHlCQUFNb0QsaUJBQWlCLEVBQXZCO0FBQUEsaUJBRFg7QUFFRSxxQkFBSyxFQUFDLFNBRlI7QUFHRSx5QkFBUyxFQUFDLE1BSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREQsR0FRRyxJQVROLEVBZUdwRCxTQUFTLGdCQUNSLHFFQUFDLGlFQUFEO0FBQWlCLDBCQUFVLEVBQUVxRCxrREFBN0I7QUFBeUMsdUJBQU8sRUFBRTNDO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRFEsR0FFTixJQWpCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkYsbUJBREY7QUF3Q0QsQ0FyTUQ7O0dBQU1qQixTO1VBQ1dHLHFEOzs7S0FEWEgsUztBQXVNTkEsU0FBUyxDQUFDNkQsTUFBVixHQUFtQkMsd0RBQW5CO0FBRWU5RCx3RUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9hZG1pbi9ldmVudC9ldmVudC1kZXRhaWwvW2V2ZW50SWRdLmY0ODZlN2VhYWI3YTQzNWE0M2M0LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG4vLyBub2RlLmpzIGxpYnJhcnkgdGhhdCBjb25jYXRlbmF0ZXMgY2xhc3NlcyAoc3RyaW5ncylcclxuXHJcbmltcG9ydCB7IEJhciB9IGZyb20gXCJyZWFjdC1jaGFydGpzLTJcIjtcclxuLy8gcmVhY3RzdHJhcCBjb21wb25lbnRzXHJcbmltcG9ydCB7XHJcbiAgQnV0dG9uLFxyXG4gIENhcmQsXHJcbiAgQ2FyZEhlYWRlcixcclxuICBDYXJkQm9keSxcclxuICBOYXZJdGVtLFxyXG4gIE5hdkxpbmssXHJcbiAgTmF2LFxyXG4gIFByb2dyZXNzLFxyXG4gIFRhYmxlLFxyXG4gIENvbnRhaW5lcixcclxuICBSb3csXHJcbiAgQ29sLFxyXG59IGZyb20gXCJyZWFjdHN0cmFwXCI7XHJcbi8vIGxheW91dCBmb3IgdGhpcyBwYWdlXHJcbmltcG9ydCBBZG1pbiBmcm9tIFwibGF5b3V0cy9BZG1pbi5qc1wiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgSGlnaGNoYXJ0cyBmcm9tIFwiaGlnaGNoYXJ0c1wiO1xyXG5pbXBvcnQgSGlnaGNoYXJ0c1JlYWN0IGZyb20gXCJoaWdoY2hhcnRzLXJlYWN0LW9mZmljaWFsXCI7XHJcblxyXG4vLyBjb3JlIGNvbXBvbmVudHNcclxuXHJcbmNvbnN0IERhc2hib2FyZCA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG5cclxuICAvLyBjb25zdCBDaGFydCA9IHJlcXVpcmUoXCJjaGFydC5qc1wiKTtcclxuICBjb25zdCBbZGF0YVZvdGUsIHNldERhdGFWb3RlXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd0NoYXJ0LCBzZXRTaG93Q2hhcnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGV2ZW50SWQgPSByb3V0ZXIucXVlcnkuZXZlbnRJZDtcclxuXHJcbiAgY29uc3QgZ2V0RGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHsgZGF0YTogcmVzIH0gPSBhd2FpdCBheGlvcy5nZXQoXHJcbiAgICAgIGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1VSTH0vZGFzaGJvYXJkL3ZvdGUtY2FuZGlkYXRlLyR7ZXZlbnRJZH1gXHJcbiAgICApO1xyXG4gICAgc2V0RGF0YVZvdGUocmVzLmRhdGEpO1xyXG4gIH07XHJcblxyXG4gIC8vIGNvbnN0IG9wdGlvbnMgPSB7XHJcbiAgLy8gICBjaGFydDoge1xyXG4gIC8vICAgICB0eXBlOiBcImNvbHVtblwiLFxyXG4gIC8vICAgfSxcclxuICAvLyAgIHRpdGxlOiB7XHJcbiAgLy8gICAgIHRleHQ6IFwiXCIsXHJcbiAgLy8gICAgIGFsaWduOiBcImxlZnRcIixcclxuICAvLyAgIH0sXHJcbiAgLy8gICBzdWJ0aXRsZToge1xyXG4gIC8vICAgICB0ZXh0OiBcIlwiLFxyXG4gIC8vICAgICBhbGlnbjogXCJsZWZ0XCIsXHJcbiAgLy8gICB9LFxyXG5cclxuICAvLyAgIHhBeGlzOiB7XHJcbiAgLy8gICAgIGNhdGVnb3JpZXM6IGRhdGFWb3RlICYmIGRhdGFWb3RlLmNhdGVnb3JpZXMsXHJcbiAgLy8gICAgIGNyb3NzaGFpcjogdHJ1ZSxcclxuICAvLyAgICAgYWNjZXNzaWJpbGl0eToge1xyXG4gIC8vICAgICAgIGRlc2NyaXB0aW9uOiBcIkthbmRpZGF0XCIsXHJcbiAgLy8gICAgIH0sXHJcbiAgLy8gICB9LFxyXG4gIC8vICAgY3JlZGl0czoge1xyXG4gIC8vICAgICBlbmFibGVkOiBmYWxzZSxcclxuICAvLyAgIH0sXHJcbiAgLy8gICB5QXhpczoge1xyXG4gIC8vICAgICBtaW46IDAsXHJcbiAgLy8gICAgIHRpdGxlOiB7XHJcbiAgLy8gICAgICAgdGV4dDogXCJKdW1sYWhcIixcclxuICAvLyAgICAgfSxcclxuICAvLyAgICAgQW5pbWF0aW9uOiB0cnVlLFxyXG4gIC8vICAgfSxcclxuICAvLyAgIHRvb2x0aXA6IHtcclxuICAvLyAgICAgdmFsdWVTdWZmaXg6IFwiXCIsXHJcbiAgLy8gICB9LFxyXG4gIC8vICAgcGxvdE9wdGlvbnM6IHtcclxuICAvLyAgICAgY29sdW1uOiB7XHJcbiAgLy8gICAgICAgcG9pbnRQYWRkaW5nOiAwLjIsXHJcbiAgLy8gICAgICAgYm9yZGVyV2lkdGg6IDAsXHJcbiAgLy8gICAgIH0sXHJcbiAgLy8gICB9LFxyXG4gIC8vICAgc2VyaWVzOiBbeyBuYW1lOiBcIkthbmRpZGF0XCIsIGRhdGE6IGRhdGFWb3RlICYmIGRhdGFWb3RlPy5zZXJpZXM/LmRhdGEgfV0sXHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgIGNoYXJ0OiB7XHJcbiAgICAgIHR5cGU6IFwiYmFyXCIsXHJcbiAgICB9LFxyXG5cclxuICAgIGV4cG9ydGluZzoge1xyXG4gICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgfSxcclxuICAgIHRpdGxlOiB7XHJcbiAgICAgIHRleHQ6IFwiXCIsXHJcbiAgICAgIGFsaWduOiBcImxlZnRcIixcclxuICAgIH0sXHJcbiAgICBzdWJ0aXRsZToge1xyXG4gICAgICB0ZXh0OiBcIlwiLFxyXG5cclxuICAgICAgYWxpZ246IFwibGVmdFwiLFxyXG4gICAgfSxcclxuICAgIHhBeGlzOiB7XHJcbiAgICAgIGNhdGVnb3JpZXM6IGRhdGFWb3RlICYmIGRhdGFWb3RlLmNhdGVnb3JpZXMsXHJcbiAgICAgIHRpdGxlOiB7XHJcbiAgICAgICAgdGV4dDogbnVsbCxcclxuICAgICAgfSxcclxuICAgICAgZ3JpZExpbmVXaWR0aDogMSxcclxuICAgICAgbGluZVdpZHRoOiAwLFxyXG4gICAgfSxcclxuICAgIHlBeGlzOiB7XHJcbiAgICAgIG1pbjogMCxcclxuICAgICAgdGl0bGU6IHtcclxuICAgICAgICB0ZXh0OiBcIlwiLFxyXG4gICAgICAgIGFsaWduOiBcImhpZ2hcIixcclxuICAgICAgfSxcclxuICAgICAgbGFiZWxzOiB7XHJcbiAgICAgICAgb3ZlcmZsb3c6IFwianVzdGlmeVwiLFxyXG4gICAgICB9LFxyXG4gICAgICBncmlkTGluZVdpZHRoOiAwLFxyXG4gICAgICB0aWNrSW50ZXJ2YWw6IDEsXHJcbiAgICB9LFxyXG4gICAgdG9vbHRpcDoge1xyXG4gICAgICB4OiB7XHJcbiAgICAgICAgZm9ybWF0dGVyOiBmdW5jdGlvbiAoXHJcbiAgICAgICAgICB2YWx1ZSxcclxuICAgICAgICAgIHsgc2VyaWVzLCBzZXJpZXNJbmRleCwgZGF0YVBvaW50SW5kZXgsIHcgfVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgZXhwb3J0aW5nOiB7XHJcbiAgICAgIGJ1dHRvbnM6IHtcclxuICAgICAgICBjb250ZXh0QnV0dG9uOiB7XHJcbiAgICAgICAgICBtZW51SXRlbXM6IFtcclxuICAgICAgICAgICAgXCJ2aWV3RnVsbHNjcmVlblwiLFxyXG4gICAgICAgICAgICBcInNlcGFyYXRvclwiLFxyXG4gICAgICAgICAgICBcImRvd25sb2FkUE5HXCIsXHJcbiAgICAgICAgICAgIFwiZG93bmxvYWRTVkdcIixcclxuICAgICAgICAgICAgXCJkb3dubG9hZFBERlwiLFxyXG4gICAgICAgICAgICBcInNlcGFyYXRvclwiLFxyXG4gICAgICAgICAgICBcImRvd25sb2FkWExTXCIsXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgbmF2aWdhdGlvbjoge1xyXG4gICAgICBidXR0b25PcHRpb25zOiB7XHJcbiAgICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgICB2ZXJ0aWNhbEFsaWduOiBcInRvcFwiLFxyXG4gICAgICAgIHk6IDAsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgcGxvdE9wdGlvbnM6IHtcclxuICAgICAgYmFyOiB7XHJcbiAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxyXG4gICAgICAgIGRhdGFMYWJlbHM6IHtcclxuICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBncm91cFBhZGRpbmc6IDAuMSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBsZWdlbmQ6IHtcclxuICAgICAgLy8gbGF5b3V0OiBcInRvcFwiLFxyXG4gICAgICBpdGVtRGlzdGFuY2U6IDEsXHJcbiAgICAgIGFsaWduOiBcImNlbnRlclwiLFxyXG4gICAgICB2ZXJ0aWNhbEFsaWduOiBcImJvdHRvbVwiLFxyXG4gICAgICBmbG9hdGluZzogZmFsc2UsXHJcbiAgICAgIGJvcmRlcldpZHRoOiAxLFxyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI0ZGRkZGRlwiLFxyXG4gICAgICBzaGFkb3c6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgY3JlZGl0czoge1xyXG4gICAgICBlbmFibGVkOiBmYWxzZSxcclxuICAgIH0sXHJcbiAgICBzZXJpZXM6IFt7IG5hbWU6IFwiVm90ZVwiLCBkYXRhOiBkYXRhVm90ZSAmJiBkYXRhVm90ZT8uc2VyaWVzPy5kYXRhIH1dLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFjdGl2ZUNoYXJ0ID0gKCkgPT4ge1xyXG4gICAgZ2V0RGF0YSgpO1xyXG4gICAgc2V0U2hvd0NoYXJ0KHRydWUpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7LyogUGFnZSBjb250ZW50ICovfVxyXG4gICAgICA8Q29udGFpbmVyIGZsdWlkIGNsYXNzTmFtZT1cIm10LTNcIj5cclxuICAgICAgICA8Um93IGNsYXNzTmFtZT1cImp1c3RpZnktY29udGVudC1jZW50ZXJcIj5cclxuICAgICAgICAgIDxDb2wgeGw9XCI4XCIgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3dcIj5cclxuICAgICAgICAgICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJiZy10cmFuc3BhcmVudFwiPlxyXG4gICAgICAgICAgICAgICAgPFJvdyBjbGFzc05hbWU9XCJhbGlnbi1pdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPGg2IGNsYXNzTmFtZT1cInRleHQtdXBwZXJjYXNlIHRleHQtbXV0ZWQgbHMtMSBtYi0xXCI+UGVyZm9ybWFuY2U8L2g2PiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibWItMFwiPkhhc2lsIFZvdGU8L2gyPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgIDwvQ2FyZEhlYWRlcj5cclxuICAgICAgICAgICAgICA8Q2FyZEJvZHk+XHJcbiAgICAgICAgICAgICAgICB7c2hvd0NoYXJ0ID09PSBmYWxzZSA/IChcclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFjdGl2ZUNoYXJ0KCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0zXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEthbGt1bGFzaSBTZWthcmFuZ1xyXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICkgOiBudWxsfVxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBDaGFydCAqL31cclxuICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImNoYXJ0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YT17Y2hhcnRIYXNpbFZvdGUuZGF0YX0gb3B0aW9ucz17Y2hhcnRIYXNpbFZvdGUub3B0aW9uc30gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgIHtzaG93Q2hhcnQgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxIaWdoY2hhcnRzUmVhY3QgaGlnaGNoYXJ0cz17SGlnaGNoYXJ0c30gb3B0aW9ucz17b3B0aW9uc30gLz5cclxuICAgICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICAgIDwvQ2FyZEJvZHk+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDwvUm93PlxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5EYXNoYm9hcmQubGF5b3V0ID0gQWRtaW47XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmQ7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=